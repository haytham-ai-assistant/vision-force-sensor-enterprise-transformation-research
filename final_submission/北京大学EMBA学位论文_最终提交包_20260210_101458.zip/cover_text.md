# 视觉力学传感器企业战略转型研究——以HSM为例

## Research on Strategic Transformation of Vision Force Sensor Enterprises——Taking HSM as an Example

### 硕士学位论文

**作者：老毕**

**学院：北京大学汇丰商学院**

**专业：高级管理人员工商管理硕士（EMBA）**

**导师：宋教授**

**日期：2026年2月**

---
